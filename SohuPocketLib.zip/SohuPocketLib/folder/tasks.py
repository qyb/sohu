from celery.tasks import Task
class ak(Task):
    def run(self):
        print a

